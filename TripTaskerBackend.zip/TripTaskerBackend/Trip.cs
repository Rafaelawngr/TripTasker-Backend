﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using static TripTaskerBackend.TaskItem;

namespace TripTaskerBackend
{
    public class Trip
    {
        public int TripId { get; set; }
        public string Title { get; set; }

        public virtual ICollection<TaskItem> TaskItems { get; set; }
    }
}