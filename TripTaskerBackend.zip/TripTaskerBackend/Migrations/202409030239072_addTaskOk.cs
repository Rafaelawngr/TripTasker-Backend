﻿namespace TripTaskerBackend.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addTaskOk : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
